Machine Learning Control -- Taming Nonlinear Dynamics and Turbulence
Thomas Duriez, Steven L. Brunton & Bernd R. Noack
Springer Publisher

Codes printed in the Springer text book 
Code2-1.m (Section 2.3.1, page 34) 
____[Internal: matlab_MLC/c2/c2s2_TP1.m]
Code2-2.m (Section 2.3.1, page 35) 
____[Internal: matlab_MLC/c2/c2s2_TP3.m]
Code2-3.m (Section 2.3.2, page 38) 
____[Internal: matlab_MLC/c2/c2s2_DS2.m]

Functions used for Section 2.3.2
function unidim_DS_evaluator.m 
____[Internal: matla_MLCb/c2/*]
parameter script unidim_DS_script.m 
____[Internal: matlab_MLC/c2/*]

Directory Tools contains all MLC sources used in the book.
MLC (MLC.m)
mlc.go (go.m),
mlc.show_best_indiv (show_best_indiv.m)
mlc.show_convergence.m (show_convergence.m)
____[Internal: matlab_MLC/MLC1/@MLC]

Internal remark: a second version of some functions
is supplied in the following directory (non-public)
____[Internal: matlab:MLC/MLC2@MLC]





function mlc=my_new_functionality(mlc)
mlc.population.individuals=cell(1,mlc.parameters.size);
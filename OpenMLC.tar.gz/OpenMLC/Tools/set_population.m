function mlc=set_population(mlc,new_population)
mlc.population=new_population;
end
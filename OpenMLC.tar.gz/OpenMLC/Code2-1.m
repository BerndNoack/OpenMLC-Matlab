clear all
close all

mlc=MLC % creates a MLC object with default values that
        % implements the simple regression problem.
